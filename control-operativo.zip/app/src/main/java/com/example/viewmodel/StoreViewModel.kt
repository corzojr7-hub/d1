package com.example.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.example.model.Instruccion
import com.example.model.InstructionStatus
import com.example.model.Merma
import com.example.model.MermaReason
import com.example.model.MermaStatus
import com.example.model.PredefinedMockData
import com.example.model.Priority
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Screen {
    DASHBOARD,
    NUEVA_INSTRUCCION,
    NUEVA_MERMA,
    HISTORIAL_INSTRUCCIONES,
    HISTORIAL_MERMAS
}

class StoreViewModel : ViewModel() {

    // Theme Mode
    var isDarkTheme = mutableStateOf(false)

    // Current Navigation Screen
    var currentScreen = mutableStateOf(Screen.DASHBOARD)

    // Currently logged-in/acting user in the store (Supervisor, 2nd, or 3rd)
    var activeUser = mutableStateOf(PredefinedMockData.rolesMock[0]) // Starts with Carlos Gomez (Supervisor)

    // Global Collections
    val instrucciones = mutableStateListOf<Instruccion>().apply {
        addAll(PredefinedMockData.instruccionesIniciales)
    }

    val mermas = mutableStateListOf<Merma>().apply {
        addAll(PredefinedMockData.mermasIniciales)
    }

    // --- FILTERS FOR INSTRUCTIONS HISTORY ---
    val filterInstruccionResponsable = mutableStateOf("Todos")
    val filterInstruccionPrioridad = mutableStateOf("Todos")
    val filterInstruccionEstado = mutableStateOf("Todos")
    val filterInstruccionBusqueda = mutableStateOf("")

    // --- FILTERS FOR MERMA HISTORY ---
    val filterMermaMotivo = mutableStateOf("Todos")
    val filterMermaResponsable = mutableStateOf("Todos")
    val filterMermaEstado = mutableStateOf("Todos")
    val filterMermaBusqueda = mutableStateOf("") // matches product name or barcode

    // Helper to get formatted local time for submissions automatically
    fun getCurrentFormattedTime(): String {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            sdf.format(Date())
        } catch (e: Exception) {
            "2026-06-06 20:10" // reliable fallback
        }
    }

    // --- OPERATIONS ---

    fun registrarInstruccion(
        responsable: String,
        instruccion: String,
        prioridad: Priority,
        observaciones: String
    ): Boolean {
        if (instruccion.isBlank() || responsable.isBlank()) return false
        val nueva = Instruccion(
            responsable = responsable,
            instruccion = instruccion,
            prioridad = prioridad,
            estado = InstructionStatus.PENDIENTE,
            observaciones = observaciones,
            fechaHora = getCurrentFormattedTime(),
            creador = activeUser.value
        )
        // Insert at the beginning to see recently added first
        instrucciones.add(0, nueva)
        return true
    }

    fun registrarMerma(
        codigoBarras: String,
        producto: String,
        categoria: String,
        cantidad: Double,
        unidad: String,
        motivo: MermaReason,
        areaCuadrante: String,
        observaciones: String,
        fotoAdjunta: String?
    ): Boolean {
        if (producto.isBlank() || cantidad <= 0.0 || codigoBarras.isBlank()) return false
        val nueva = Merma(
            codigoBarras = codigoBarras,
            producto = producto,
            categoria = categoria,
            cantidad = cantidad,
            unidad = unidad,
            motivo = motivo,
            responsableDeposito = activeUser.value,
            areaCuadrante = areaCuadrante,
            observaciones = observaciones,
            fotoAdjunta = fotoAdjunta,
            estadoRevision = MermaStatus.PENDIENTE,
            fechaHora = getCurrentFormattedTime()
        )
        mermas.add(0, nueva)
        return true
    }

    fun actualizarEstadoInstruccion(id: String, nuevoEstado: InstructionStatus, observacionAdicional: String = "") {
        val index = instrucciones.indexOfFirst { it.id == id }
        if (index != -1) {
            val original = instrucciones[index]
            val obsString = if (observacionAdicional.isNotBlank()) {
                if (original.observaciones.isNotBlank()) {
                    original.observaciones + "\n[Act: " + observacionAdicional + "]"
                } else observacionAdicional
            } else original.observaciones

            instrucciones[index] = original.copy(
                estado = nuevoEstado,
                observaciones = obsString
            )
        }
    }

    fun resolverORevisarMerma(id: String, nuevoEstado: MermaStatus) {
        val index = mermas.indexOfFirst { it.id == id }
        if (index != -1) {
            mermas[index] = mermas[index].copy(estadoRevision = nuevoEstado)
        }
    }

    // --- GETTER/FILTER LOGICS ---

    fun getFilteredInstrucciones(): List<Instruccion> {
        return instrucciones.filter { inst ->
            val matchResp = filterInstruccionResponsable.value == "Todos" || inst.responsable == filterInstruccionResponsable.value
            val matchPrio = filterInstruccionPrioridad.value == "Todos" || inst.prioridad.label == filterInstruccionPrioridad.value
            val matchEst = filterInstruccionEstado.value == "Todos" || inst.estado.label == filterInstruccionEstado.value
            val query = filterInstruccionBusqueda.value.lowercase().trim()
            val matchQuery = query.isEmpty() || inst.instruccion.lowercase().contains(query) || inst.creador.lowercase().contains(query) || inst.observaciones.lowercase().contains(query)
            
            matchResp && matchPrio && matchEst && matchQuery
        }
    }

    fun getFilteredMermas(): List<Merma> {
        return mermas.filter { mm ->
            val matchMot = filterMermaMotivo.value == "Todos" || mm.motivo.label == filterMermaMotivo.value
            val matchResp = filterMermaResponsable.value == "Todos" || mm.responsableDeposito == filterMermaResponsable.value
            val matchEst = filterMermaEstado.value == "Todos" || mm.estadoRevision.label == filterMermaEstado.value
            val query = filterMermaBusqueda.value.lowercase().trim()
            val matchQuery = query.isEmpty() || mm.producto.lowercase().contains(query) || mm.codigoBarras.contains(query) || mm.observaciones.lowercase().contains(query)
            
            matchMot && matchResp && matchEst && matchQuery
        }
    }

    // Quick Stats for Dashboard Card summaries
    fun getInstruccionesPendientesHoyCount(): Int {
        return instrucciones.count { it.estado != InstructionStatus.COMPLETADO }
    }

    fun getMermasPendientesRevisionCount(): Int {
        return mermas.count { it.estadoRevision == MermaStatus.PENDIENTE }
    }

    fun getMermasTotalesHoySum(): Double {
        // Just sum all quantities registered
        return mermas.sumOf { it.cantidad }
    }

    // Clears all filters to reset
    fun resetInstruccionFilters() {
        filterInstruccionResponsable.value = "Todos"
        filterInstruccionPrioridad.value = "Todos"
        filterInstruccionEstado.value = "Todos"
        filterInstruccionBusqueda.value = ""
    }

    fun resetMermaFilters() {
        filterMermaMotivo.value = "Todos"
        filterMermaResponsable.value = "Todos"
        filterMermaEstado.value = "Todos"
        filterMermaBusqueda.value = ""
    }
}
