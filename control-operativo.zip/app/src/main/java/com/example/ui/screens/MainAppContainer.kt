package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PredefinedMockData
import com.example.viewmodel.Screen
import com.example.viewmodel.StoreViewModel

import androidx.compose.foundation.shape.CircleShape

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContainer(
    viewModel: StoreViewModel
) {
    val currentScreen by remember { viewModel.currentScreen }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        val isWideScreen = maxWidth > 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // D1 Mini Branded Symbol Logo look with "Tiendas D1 de todos!"
                            Box(
                                modifier = Modifier
                                    .padding(end = 8.dp)
                                    .background(Color.White, shape = RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "D1",
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFD21F26), // D1 Red
                                    fontSize = 14.sp
                                )
                            }
                            Column {
                                Text(
                                    text = "Tiendas D1 de todos!",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "Control de Operaciones • Tienda 402",
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFFD21F26), // Solid Brand Red Header!
                        titleContentColor = Color.White,
                        actionIconContentColor = Color.White
                    ),
                    actions = {
                        // Supervisor Profile widget on the top-right matching the screenshot
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.15f), shape = RoundedCornerShape(12.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AccountCircle,
                                        contentDescription = "User info",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = viewModel.activeUser.value.substringBefore(" ") + " / Perfil: Supervisor",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    },
                    modifier = Modifier.testTag("app_top_bar")
                )
            },
            bottomBar = {
                // If it is mobile size, show Bottom Navigation, else hide it
                if (!isWideScreen) {
                    StoreBottomNavigationBar(
                        currentScreen = currentScreen,
                        onScreenSelected = { viewModel.currentScreen.value = it }
                    )
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // If it is wide screen size (Computer/Tablet), show Side Rail navigation
                if (isWideScreen) {
                    StoreNavigationRail(
                        currentScreen = currentScreen,
                        onScreenSelected = { viewModel.currentScreen.value = it }
                    )
                    VerticalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                }

                // Main screen view switcher container
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    Crossfade(
                        targetState = currentScreen,
                        label = "ScreenTransition"
                    ) { screen ->
                        when (screen) {
                            Screen.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                            Screen.NUEVA_INSTRUCCION -> InstruccionFormScreen(viewModel = viewModel)
                            Screen.NUEVA_MERMA -> MermaFormScreen(viewModel = viewModel)
                            Screen.HISTORIAL_INSTRUCCIONES -> InstructionsHistoryScreen(viewModel = viewModel)
                            Screen.HISTORIAL_MERMAS -> MermaHistoryScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StoreBottomNavigationBar(
    currentScreen: Screen,
    onScreenSelected: (Screen) -> Unit
) {
    NavigationBar(
        modifier = Modifier.fillMaxWidth().testTag("store_bottom_nav"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = currentScreen == Screen.DASHBOARD,
            onClick = { onScreenSelected(Screen.DASHBOARD) },
            label = { Text("Panel", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == Screen.DASHBOARD) Icons.Default.Dashboard else Icons.Default.Dashboard,
                    contentDescription = "Dashboard"
                )
            },
            modifier = Modifier.testTag("nav_dashboard")
        )

        NavigationBarItem(
            selected = currentScreen == Screen.HISTORIAL_INSTRUCCIONES || currentScreen == Screen.NUEVA_INSTRUCCION,
            onClick = { onScreenSelected(Screen.HISTORIAL_INSTRUCCIONES) },
            label = { Text("Instrucciones", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Assignment,
                    contentDescription = "Instrucciones"
                )
            },
            modifier = Modifier.testTag("nav_instructions")
        )

        NavigationBarItem(
            selected = currentScreen == Screen.HISTORIAL_MERMAS || currentScreen == Screen.NUEVA_MERMA,
            onClick = { onScreenSelected(Screen.HISTORIAL_MERMAS) },
            label = { Text("Merma", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            icon = {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Merma"
                )
            },
            modifier = Modifier.testTag("nav_mermas")
        )
    }
}

@Composable
fun StoreNavigationRail(
    currentScreen: Screen,
    onScreenSelected: (Screen) -> Unit
) {
    NavigationRail(
        modifier = Modifier.fillMaxHeight().testTag("store_nav_rail"),
        containerColor = MaterialTheme.colorScheme.surface,
        header = {
            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "D1",
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontSize = 18.sp
                )
            }
        }
    ) {
        Column(
            modifier = Modifier.fillMaxHeight(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NavigationRailItem(
                selected = currentScreen == Screen.DASHBOARD,
                onClick = { onScreenSelected(Screen.DASHBOARD) },
                label = { Text("Dashboard", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(imageVector = Icons.Default.Dashboard, contentDescription = "Dashboard") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            NavigationRailItem(
                selected = currentScreen == Screen.HISTORIAL_INSTRUCCIONES || currentScreen == Screen.NUEVA_INSTRUCCION,
                onClick = { onScreenSelected(Screen.HISTORIAL_INSTRUCCIONES) },
                label = { Text("Instrucciones", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(imageVector = Icons.Default.Assignment, contentDescription = "Instrucciones") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            NavigationRailItem(
                selected = currentScreen == Screen.HISTORIAL_MERMAS || currentScreen == Screen.NUEVA_MERMA,
                onClick = { onScreenSelected(Screen.HISTORIAL_MERMAS) },
                label = { Text("Mermas", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "Mermas") }
            )
        }
    }
}
