package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.shape.CircleShape
import com.example.model.MermaReason
import com.example.model.PredefinedMockData
import com.example.viewmodel.Screen
import com.example.viewmodel.StoreViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MermaFormScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    var codigoBarras by remember { mutableStateOf("") }
    var producto by remember { mutableStateOf("") }
    var categoria by remember { mutableStateOf(PredefinedMockData.categoriasProductos[0]) }
    var cantidadText by remember { mutableStateOf("") }
    var unidad by remember { mutableStateOf("Unidades") }
    var motivo by remember { mutableStateOf(MermaReason.VENCIMIENTO) }
    var areaCuadrante by remember { mutableStateOf(PredefinedMockData.areasCuadrantes[0]) }
    var observaciones by remember { mutableStateOf("") }
    var fotoAdjunta by remember { mutableStateOf<String?>(null) }

    var expandedCat by remember { mutableStateOf(false) }
    var expandedUnidad by remember { mutableStateOf(false) }
    var expandedArea by remember { mutableStateOf(false) }

    var showError by remember { mutableStateOf(false) }
    var showSuccessSnackbar by remember { mutableStateOf(false) }
    var isSimulatingCamera by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("new_merma_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Form Title & Back Action
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = { viewModel.currentScreen.value = Screen.DASHBOARD },
                modifier = Modifier.testTag("back_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Volver al Dashboard"
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Registrar Nueva Merma",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "Control obligatorio de pérdidas por avería o vencimiento",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
        }

        // Quick Scan Simulator Panel ("Para el trabajador con afán")
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Simulador de Escáner Portátil",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = "En la tienda D1, se usaría un lector láser. Toca un producto frecuente para autocompletar:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Quick selector buttons
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PredefinedMockData.productosPredeterminados.forEach { prod ->
                        Button(
                            onClick = {
                                codigoBarras = prod.first
                                producto = prod.second
                                categoria = prod.third
                                cantidadText = "1"
                                showError = false
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surface,
                                contentColor = MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(20.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 1.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                modifier = Modifier.size(12.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = prod.second.substringBefore(" "), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Section: Barcode and Product Name
        Text(
            text = "1. Identificación del Producto",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = codigoBarras,
                onValueChange = {
                    codigoBarras = it
                    showError = false
                },
                modifier = Modifier
                    .weight(1.2f)
                    .testTag("barcode_field"),
                label = { Text("Código de Barras") },
                placeholder = { Text("770200...") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(8.dp),
                isError = showError && codigoBarras.isBlank()
            )

            OutlinedTextField(
                value = producto,
                onValueChange = {
                    producto = it
                    showError = false
                },
                modifier = Modifier
                    .weight(1.8f)
                    .testTag("product_name_field"),
                label = { Text("Nombre del Producto") },
                placeholder = { Text("Ej: Café Sello Rojo 500g") },
                shape = RoundedCornerShape(8.dp),
                isError = showError && producto.isBlank()
            )
        }

        // Section: Category Selector
        Box {
            OutlinedTextField(
                value = categoria,
                onValueChange = {},
                readOnly = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expandedCat = true },
                label = { Text("Categoría del Surtido") },
                trailingIcon = {
                    IconButton(onClick = { expandedCat = true }) {
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Cambiar")
                    }
                },
                shape = RoundedCornerShape(8.dp)
            )

            DropdownMenu(
                expanded = expandedCat,
                onDismissRequest = { expandedCat = false },
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                PredefinedMockData.categoriasProductos.forEach { cat ->
                    DropdownMenuItem(
                        text = { Text(cat) },
                        onClick = {
                            categoria = cat
                            expandedCat = false
                        }
                    )
                }
            }
        }

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        // Section: Quantity and Unit
        Text(
            text = "2. Cantidad y Unidad de Medida",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = cantidadText,
                onValueChange = {
                    cantidadText = it
                    showError = false
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("quantity_field"),
                label = { Text("Cantidad de Merma") },
                placeholder = { Text("Ej: 4") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(8.dp),
                isError = showError && (cantidadText.toDoubleOrNull() ?: 0.0) <= 0.0
            )

            Box(modifier = Modifier.weight(1f)) {
                OutlinedTextField(
                    value = unidad,
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedUnidad = true },
                    label = { Text("Unidad de Medida") },
                    trailingIcon = {
                        IconButton(onClick = { expandedUnidad = true }) {
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Cambiar")
                        }
                    },
                    shape = RoundedCornerShape(8.dp)
                )

                DropdownMenu(
                    expanded = expandedUnidad,
                    onDismissRequest = { expandedUnidad = false }
                ) {
                    PredefinedMockData.unidadesMedida.forEach { un ->
                        DropdownMenuItem(
                            text = { Text(un) },
                            onClick = {
                                unidad = un
                                expandedUnidad = false
                            }
                        )
                    }
                }
            }
        }

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        // Section: Motivo Merma
        Text(
            text = "3. Motivo del Descarte de Producto",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MermaReason.values().forEach { r ->
                val isSelected = motivo == r
                val chipColor = when (r) {
                    MermaReason.VENCIMIENTO -> HighDensityRose
                    MermaReason.AVARIA -> HighDensityAmber
                    MermaReason.ROTURA -> HighDensitySlate
                    MermaReason.MAL_ESTADO -> HighDensityGreen
                    MermaReason.CADENA_FRIO -> Color(0xFF7C69A2)
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) chipColor else Color.Transparent)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) chipColor else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { motivo = r }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = r.label,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        // Section: Area / Cuadrante
        Text(
            text = "4. Cuadrante o Área de Hallazgo",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = areaCuadrante,
                onValueChange = {},
                readOnly = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expandedArea = true },
                label = { Text("Área de la Tienda") },
                trailingIcon = {
                    IconButton(onClick = { expandedArea = true }) {
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Cambiar")
                    }
                },
                shape = RoundedCornerShape(8.dp)
            )

            DropdownMenu(
                expanded = expandedArea,
                onDismissRequest = { expandedArea = false },
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                PredefinedMockData.areasCuadrantes.forEach { area ->
                    DropdownMenuItem(
                        text = { Text(area) },
                        onClick = {
                            areaCuadrante = area
                            expandedArea = false
                        }
                    )
                }
            }
        }

        // Section: Observation
        OutlinedTextField(
            value = observaciones,
            onValueChange = { observaciones = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Observaciones del descarte") },
            placeholder = { Text("Describe detalles (lote, estado del empaque, etc.)") },
            shape = RoundedCornerShape(8.dp)
        )

        // Section: Simulated Photo Attachment
        Text(
            text = "5. Evidencia Fotográfica Obligatoria",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = CardDefaults.outlinedCardBorder(enabled = true),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                if (fotoAdjunta != null) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Foto capturada",
                        tint = HighDensityGreen,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = fotoAdjunta!!,
                        style = MaterialTheme.typography.labelLarge,
                        color = HighDensityGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(onClick = { fotoAdjunta = null }) {
                        Text("Eliminar y Volver a Tomar")
                    }
                } else if (isSimulatingCamera) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Abriendo cámara D1 inteligente...",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    LaunchedEffect(Unit) {
                        kotlinx.coroutines.delay(1200) // fast snap
                        fotoAdjunta = "IMG_D1_${System.currentTimeMillis() % 10000}.JPG"
                        isSimulatingCamera = false
                    }
                } else {
                    IconButton(
                        onClick = { isSimulatingCamera = true },
                        modifier = Modifier
                            .size(56.dp)
                            .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoCamera,
                            contentDescription = "Simular Foto",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Encender Cámara del Celular",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Para trazabilidad, toma foto de la avería/fecha de vencimiento",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        modifier = Modifier.padding(horizontal = 16.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Display Active Actor in Tienda who registers this
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Registrado por: ${viewModel.activeUser.value} (Turno Actual)",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Action Trigger Button
        Button(
            onClick = {
                val qty = cantidadText.toDoubleOrNull() ?: 0.0
                if (codigoBarras.isBlank() || producto.isBlank() || qty <= 0.0) {
                    showError = true
                } else {
                    val success = viewModel.registrarMerma(
                        codigoBarras = codigoBarras,
                        producto = producto,
                        categoria = categoria,
                        cantidad = qty,
                        unidad = unidad,
                        motivo = motivo,
                        areaCuadrante = areaCuadrante,
                        observaciones = observaciones,
                        fotoAdjunta = fotoAdjunta
                    )
                    if (success) {
                        showSuccessSnackbar = true
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("submit_merma_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Icon(
                imageVector = Icons.Default.Save,
                contentDescription = null
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Registrar Baja de Merma en Turno",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(32.dp))
    }

    if (showSuccessSnackbar) {
        AlertDialog(
            onDismissRequest = {
                showSuccessSnackbar = false
                viewModel.currentScreen.value = Screen.DASHBOARD
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessSnackbar = false
                        viewModel.currentScreen.value = Screen.DASHBOARD
                    }
                ) {
                    Text("OK")
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = HighDensityGreen,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Registro Guardado")
                }
            },
            text = {
                Text("El descarte de merma ha sido agregado exitosamente. Queda pendiente para la auditoría diaria del Supervisor.")
            }
        )
    }
}
