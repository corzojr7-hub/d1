package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Instruccion
import com.example.model.InstructionStatus
import com.example.model.Merma
import com.example.model.PredefinedMockData
import com.example.model.Priority
import com.example.viewmodel.Screen
import com.example.viewmodel.StoreViewModel
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Welcome and Role Indicator
        item {
            StoreHeaderSection(viewModel)
        }

        // 2. Alertas de Seguimiento Críticas
        item {
            AlertsSection(viewModel)
        }

        // 3. Tarjetas Resumen (KPIs)
        item {
            KpiSummaryCards(viewModel)
        }

        // 4. Quick Operational Shortcuts
        item {
            QuickActionsSection(viewModel)
        }

        // 5. Recent Instructions header and quick list
        item {
            SectionHeader(
                title = "Instrucciones del Día",
                subtitle = "Tareas asignadas para controlar operación",
                actionText = "Ver Todo",
                onActionClicked = { viewModel.currentScreen.value = Screen.HISTORIAL_INSTRUCCIONES }
            )
        }

        val pendingInstructions = viewModel.instrucciones.take(3)
        if (pendingInstructions.isEmpty()) {
            item {
                EmptyStateCard(text = "No hay instrucciones reportadas hoy.")
            }
        } else {
            items(pendingInstructions) { instruccion ->
                InstructionDashboardItem(instruccion, viewModel)
            }
        }

        // 6. Recent Mermas header and quick list
        item {
            SectionHeader(
                title = "Registros de Merma Recientes",
                subtitle = "Trazabilidad de averías y mermas en tienda",
                actionText = "Ver Todo",
                onActionClicked = { viewModel.currentScreen.value = Screen.HISTORIAL_MERMAS }
            )
        }

        val recentMermas = viewModel.mermas.take(3)
        if (recentMermas.isEmpty()) {
            item {
                EmptyStateCard(text = "No se han registrado mermas recientemente.")
            }
        } else {
            items(recentMermas) { merma ->
                MermaDashboardItem(merma, viewModel)
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun StoreHeaderSection(viewModel: StoreViewModel) {
    var expandedDropdown by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder(enabled = true).copy(
            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE2E8F0))
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "D1 - Tienda Kennedy 402",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "CONTROL DE TURNO ACTIVO",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            // User Role Selector Dropdown
            Box {
                FilledTonalButton(
                    onClick = { expandedDropdown = true },
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Usuario",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = viewModel.activeUser.value.substringBefore(" "),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Cambiar",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }

                DropdownMenu(
                    expanded = expandedDropdown,
                    onDismissRequest = { expandedDropdown = false }
                ) {
                    PredefinedMockData.rolesMock.forEach { role ->
                        DropdownMenuItem(
                            text = { Text(text = role, style = MaterialTheme.typography.bodyMedium) },
                            onClick = {
                                viewModel.activeUser.value = role
                                expandedDropdown = false
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (role.contains("Supervisor")) Icons.Default.AdminPanelSettings else Icons.Default.Person,
                                    contentDescription = null
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AlertsSection(viewModel: StoreViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(24.dp),
        border = CardDefaults.outlinedCardBorder(enabled = true).copy(
            brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
        )
    ) {
        Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            // Highly Visible Accent Tag top right - beautiful desaturated amber
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFFEF3C7)) // soft amber-100
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "ALTA PRIORIDAD",
                    color = Color(0xFFD97706), // desaturated amber-700
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "INSTRUCCIÓN ACTIVA",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Revisión de Vencimientos: Pasillo 3 (Lácteos)",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Resp: ",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Text(
                            text = "Liliana Ortiz",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Plazo: ",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Text(
                            text = "10:30 AM",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KpiSummaryCards(viewModel: StoreViewModel) {
    val pendingInst = viewModel.getInstruccionesPendientesHoyCount()
    val totalMermaCant = viewModel.getMermasTotalesHoySum()

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        KpiCard(
            title = "TAREAS PENDIENTES",
            value = if (pendingInst < 10) "0$pendingInst" else "$pendingInst",
            subtext = "+3 HOY",
            badgeText = "PENDIENTES",
            color = HighDensitySlate, // D1 Blue
            badgeBg = Color(0xFFEBF3FC), // Soft blue tint
            badgeColor = HighDensitySlate,
            icon = Icons.Default.Assignment,
            modifier = Modifier.weight(1f)
        )

        KpiCard(
            title = "MERMA DEL DÍA",
            value = "$${"%.0fk".format(totalMermaCant * 3)}", // Format like "$42k"
            subtext = "6 REGISTROS",
            badgeText = "REGISTRADO",
            color = HighDensityRose, // Official Red
            badgeBg = HighDensityRoseLight, // Soft red tint
            badgeColor = HighDensityRose,
            icon = Icons.Default.DeleteSweep,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    subtext: String,
    badgeText: String,
    color: Color,
    badgeBg: Color,
    badgeColor: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder(enabled = true).copy(
            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE2E8F0))
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF64748B),
                letterSpacing = 0.5.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = value,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    color = color
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(badgeBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badgeText,
                        color = badgeColor,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun QuickActionsSection(viewModel: StoreViewModel) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier
                .weight(1f)
                .clickable { viewModel.currentScreen.value = Screen.NUEVA_INSTRUCCION }
                .testTag("action_new_instruction"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AddTask,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    text = "Nueva Instrucción",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Asignar orden de trabajo urgente",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }

        Card(
            modifier = Modifier
                .weight(1f)
                .clickable { viewModel.currentScreen.value = Screen.NUEVA_MERMA }
                .testTag("action_new_merma"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    text = "Registrar Merma",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Trazabilidad de avería o merma",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String,
    actionText: String,
    onActionClicked: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }
        TextButton(onClick = onActionClicked) {
            Text(text = actionText, style = MaterialTheme.typography.labelLarge)
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun InstructionDashboardItem(
    instruccion: Instruccion,
    viewModel: StoreViewModel
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { viewModel.currentScreen.value = Screen.HISTORIAL_INSTRUCCIONES },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder(enabled = true)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Priority Badge
                val priorityColor = when (instruccion.prioridad) {
                    Priority.ALTA -> HighDensityRose
                    Priority.MEDIA -> HighDensityAmber
                    Priority.BAJA -> HighDensityGreen
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(priorityColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Prioridad ${instruccion.prioridad.label}",
                        color = priorityColor,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Interactive Quick Status Toggle
                var statusExpanded by remember { mutableStateOf(false) }
                Box {
                    val statusColor = when (instruccion.estado) {
                        InstructionStatus.PENDIENTE -> HighDensityAmber
                        InstructionStatus.EN_PROCESO -> HighDensityTeal
                        InstructionStatus.COMPLETADO -> HighDensityGreen
                    }
                    Button(
                        onClick = { statusExpanded = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = statusColor.copy(alpha = 0.12f),
                            contentColor = statusColor
                        ),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        Text(
                            text = instruccion.estado.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Cambiar estado",
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = statusExpanded,
                        onDismissRequest = { statusExpanded = false }
                    ) {
                        InstructionStatus.values().forEach { status ->
                            DropdownMenuItem(
                                text = { Text(status.label, style = MaterialTheme.typography.labelMedium) },
                                onClick = {
                                    viewModel.actualizarEstadoInstruccion(instruccion.id, status)
                                    statusExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = instruccion.instruccion,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (instruccion.observaciones.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.Assignment,
                        contentDescription = "Nota",
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = instruccion.observaciones,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Ordenó: ${instruccion.creador.substringBefore(" ")}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                Text(
                    text = "Para: ${instruccion.responsable.substringBefore(" ")}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

@Composable
fun MermaDashboardItem(
    merma: Merma,
    viewModel: StoreViewModel
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { viewModel.currentScreen.value = Screen.HISTORIAL_MERMAS },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder(enabled = true)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Visual Indicator of status (colored bar on left)
            val indicatorColor = when (merma.motivo) {
                com.example.model.MermaReason.VENCIMIENTO -> HighDensityRose
                com.example.model.MermaReason.AVARIA -> HighDensityAmber
                com.example.model.MermaReason.ROTURA -> HighDensityMuted
                com.example.model.MermaReason.MAL_ESTADO -> HighDensityGreen
                com.example.model.MermaReason.CADENA_FRIO -> Color(0xFF7C69A2)
            }

            // Product placeholder category icon representation
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(indicatorColor.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                val icon = when (merma.categoria) {
                    "Lácteos y Refrigerados" -> Icons.Default.AcUnit
                    "Panadería y Repostería" -> Icons.Default.BakeryDining
                    "Frutas y Verduras" -> Icons.Default.Spa
                    "Abarrotes y Despensa" -> Icons.Default.ShoppingBag
                    "Carnes y Embutidos" -> Icons.Default.Restaurant
                    "Aseo y Limpieza" -> Icons.Default.CleanHands
                    else -> Icons.Default.Inventory
                }
                Icon(
                    imageVector = icon,
                    contentDescription = merma.categoria,
                    tint = indicatorColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = merma.producto,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${merma.cantidad} ${merma.unidad.substringBefore(" ")}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Black,
                        color = indicatorColor
                    )
                }

                Text(
                    text = "Área: ${merma.areaCuadrante}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Reason Badge
                    Text(
                        text = "Motivo: ${merma.motivo.label}",
                        style = MaterialTheme.typography.labelSmall,
                        color = indicatorColor,
                        fontWeight = FontWeight.Bold
                    )

                    // Review state badge
                    val revisionColor = when (merma.estadoRevision) {
                        com.example.model.MermaStatus.PENDIENTE -> HighDensityAmber
                        com.example.model.MermaStatus.REVISADO -> HighDensityGreen
                        com.example.model.MermaStatus.RECHAZADO -> HighDensityRose
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(revisionColor.copy(alpha = 0.1f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = merma.estadoRevision.label.substringBefore(" "),
                            color = revisionColor,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyStateCard(text: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Inbox,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}
