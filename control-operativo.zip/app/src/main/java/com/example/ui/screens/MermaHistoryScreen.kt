package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Merma
import com.example.model.MermaReason
import com.example.model.MermaStatus
import com.example.model.PredefinedMockData
import com.example.viewmodel.StoreViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MermaHistoryScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { viewModel.filterMermaBusqueda }
    var selectedMotivo by remember { viewModel.filterMermaMotivo }
    var selectedResponsable by remember { viewModel.filterMermaResponsable }
    var selectedEstadoRevision by remember { viewModel.filterMermaEstado }

    // Dropdown toggle states
    var expMot by remember { mutableStateOf(false) }
    var expResp by remember { mutableStateOf(false) }
    var expEst by remember { mutableStateOf(false) }

    // Audit dialogue trigger state
    var selectedMermaForAudit by remember { mutableStateOf<Merma?>(null) }

    val filteredList = viewModel.getFilteredMermas()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("merma_history_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // App header and reset controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Control e Historial de Merma",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "Auditoría de desmedros, averías y vencimientos",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }

            IconButton(onClick = { viewModel.resetMermaFilters() }) {
                Icon(
                    imageVector = Icons.Default.FilterListOff,
                    contentDescription = "Limpiar Filtros",
                    tint = MaterialTheme.colorScheme.secondary
                )
            }
        }

        // Search Bar (Barcode or product title)
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Buscar por producto, observaciones, código...") },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            shape = RoundedCornerShape(8.dp),
            singleLine = true
        )

        // Triple filter dropdown row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Motivo Filter
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { expMot = true },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (selectedMotivo == "Todos") "Motivo" else selectedMotivo.substringBefore(" "),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(12.dp))
                }

                DropdownMenu(expanded = expMot, onDismissRequest = { expMot = false }) {
                    DropdownMenuItem(text = { Text("Todos los motivos") }, onClick = { selectedMotivo = "Todos"; expMot = false })
                    MermaReason.values().forEach { mr ->
                        DropdownMenuItem(text = { Text(mr.label) }, onClick = { selectedMotivo = mr.label; expMot = false })
                    }
                }
            }

            // Responsable Deposit Filter
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { expResp = true },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (selectedResponsable == "Todos") "Depositó" else selectedResponsable.substringBefore(" "),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(12.dp))
                }

                DropdownMenu(expanded = expResp, onDismissRequest = { expResp = false }) {
                    DropdownMenuItem(text = { Text("Todos") }, onClick = { selectedResponsable = "Todos"; expResp = false })
                    PredefinedMockData.rolesMock.forEach { role ->
                        DropdownMenuItem(text = { Text(role) }, onClick = { selectedResponsable = role; expResp = false })
                    }
                }
            }

            // Review Revision Filter
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { expEst = true },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (selectedEstadoRevision == "Todos") "Revisión" else selectedEstadoRevision.substringBefore(" "),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(12.dp))
                }

                DropdownMenu(expanded = expEst, onDismissRequest = { expEst = false }) {
                    DropdownMenuItem(text = { Text("Todos los estados") }, onClick = { selectedEstadoRevision = "Todos"; expEst = false })
                    MermaStatus.values().forEach { status ->
                        DropdownMenuItem(text = { Text(status.label) }, onClick = { selectedEstadoRevision = status.label; expEst = false })
                    }
                }
            }
        }

        // Counter status and quick labels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${filteredList.size} Registros de Merma",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
            if (selectedMotivo != "Todos" || selectedResponsable != "Todos" || selectedEstadoRevision != "Todos" || searchQuery.isNotEmpty()) {
                Text(
                    text = "Búsqueda Filtrada",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        // List elements scroll core
        if (filteredList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Ninguna merma coincide con los filtros",
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                    Text(
                        text = "Pruebe con otra palabra clave o reiniciando filtros",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredList) { item ->
                    MermaItemCard(
                        merma = item,
                        onClick = { selectedMermaForAudit = item }
                    )
                }
            }
        }
    }

    // Detail & Audit Dialog for Store Supervisor
    if (selectedMermaForAudit != null) {
        val editingMerma = selectedMermaForAudit!!

        Dialog(onDismissRequest = { selectedMermaForAudit = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Auditoría de Merma",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )

                        // Motivo color badge
                        val indicatorColor = when (editingMerma.motivo) {
                            MermaReason.VENCIMIENTO -> HighDensityRose
                            MermaReason.AVARIA -> HighDensityAmber
                            MermaReason.ROTURA -> HighDensityMuted
                            MermaReason.MAL_ESTADO -> HighDensityGreen
                            MermaReason.CADENA_FRIO -> Color(0xFF7C69A2)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(indicatorColor.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = editingMerma.motivo.label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = indicatorColor
                            )
                        }
                    }

                    // Product info
                    Text(
                        text = editingMerma.producto,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Column {
                            Text("Cantidad Registrada", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(
                                "${editingMerma.cantidad} ${editingMerma.unidad}",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column {
                            Text("Ubicación", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(
                                editingMerma.areaCuadrante,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Metadata
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "EAN Código: ${editingMerma.codigoBarras}",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                        Text(
                            text = "Categoría: ${editingMerma.categoria}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Depositado por: ${editingMerma.responsableDeposito}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Registrado a las: ${editingMerma.fechaHora}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    // Observaciones
                    if (editingMerma.observaciones.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(
                                    "Anotaciones:",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray
                                )
                                Text(
                                    editingMerma.observaciones,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    // Camera Simulated picture indicator
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (editingMerma.fotoAdjunta != null) HighDensityGreenLight else Color(0xFFECEFF1)
                            )
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (editingMerma.fotoAdjunta != null) Icons.Default.CameraAlt else Icons.Default.NoPhotography,
                            contentDescription = null,
                            tint = if (editingMerma.fotoAdjunta != null) HighDensityGreen else Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (editingMerma.fotoAdjunta != null) {
                                "Verificación Fotográfica: ${editingMerma.fotoAdjunta}"
                            } else {
                                "Sin fotografía de evidencia guardada"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = if (editingMerma.fotoAdjunta != null) HighDensityGreen else Color.Gray
                        )
                    }

                    Divider()

                    // Audit action buttons (Approving, dismissing write-offs)
                    Text(
                        "Acciones del Supervisor (Firmar Auditoría):",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.resolverORevisarMerma(editingMerma.id, MermaStatus.REVISADO)
                                selectedMermaForAudit = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = HighDensityGreen),
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Aprobar Ajuste", fontSize = 11.sp, color = Color.White)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.resolverORevisarMerma(editingMerma.id, MermaStatus.RECHAZADO)
                                selectedMermaForAudit = null
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = HighDensityRose),
                            modifier = Modifier.weight(0.8f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Rechazar", fontSize = 11.sp)
                        }
                    }

                    TextButton(
                        onClick = { selectedMermaForAudit = null },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text("Cerrar Detalles")
                    }
                }
            }
        }
    }
}

@Composable
fun MermaItemCard(
    merma: Merma,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("merma_history_item_${merma.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder(enabled = true)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // First row (Category & date stamp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Tag
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colorScheme.secondaryContainer)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = merma.categoria,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }

                // Date
                Text(
                    text = merma.fechaHora,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Product Title and Big Quantity
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = merma.producto,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Barras: ${merma.codigoBarras}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    )
                }

                Text(
                    text = "${merma.cantidad} ${merma.unidad.substringBefore(" ")}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Reason and Quadrant description
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val indicatorColor = when (merma.motivo) {
                        MermaReason.VENCIMIENTO -> HighDensityRose
                        MermaReason.AVARIA -> HighDensityAmber
                        MermaReason.ROTURA -> HighDensityMuted
                        MermaReason.MAL_ESTADO -> HighDensityGreen
                        MermaReason.CADENA_FRIO -> Color(0xFF7C69A2)
                    }
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(indicatorColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Motivo: ${merma.motivo.label}",
                        style = MaterialTheme.typography.bodySmall,
                        color = indicatorColor,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "Lugar: ${merma.areaCuadrante.substringBefore(" ")}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            // Photo and details icon bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (merma.fotoAdjunta != null) Icons.Default.CameraAlt else Icons.Default.HideImage,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = if (merma.fotoAdjunta != null) HighDensityGreen else Color.Gray
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (merma.fotoAdjunta != null) "Evidencia Adjunta" else "Sin Foto",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (merma.fotoAdjunta != null) HighDensityGreen else Color.Gray,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Revision badge
                val revisionColor = when (merma.estadoRevision) {
                    MermaStatus.PENDIENTE -> HighDensityAmber
                    MermaStatus.REVISADO -> HighDensityGreen
                    MermaStatus.RECHAZADO -> HighDensityRose
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(revisionColor.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = merma.estadoRevision.label,
                        color = revisionColor,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
