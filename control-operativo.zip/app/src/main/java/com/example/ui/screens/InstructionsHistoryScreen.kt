package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.model.Instruccion
import com.example.model.InstructionStatus
import com.example.model.PredefinedMockData
import com.example.model.Priority
import com.example.viewmodel.StoreViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstructionsHistoryScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    var searchtext by remember { viewModel.filterInstruccionBusqueda }
    var selectedResponsable by remember { viewModel.filterInstruccionResponsable }
    var selectedPrioridad by remember { viewModel.filterInstruccionPrioridad }
    var selectedEstado by remember { viewModel.filterInstruccionEstado }

    // Dropdown expanding state
    var expResp by remember { mutableStateOf(false) }
    var expPrio by remember { mutableStateOf(false) }
    var expEst by remember { mutableStateOf(false) }

    // Dialog state for updating instruction
    var selectedInstructionForEdit by remember { mutableStateOf<Instruccion?>(null) }

    val filteredList = viewModel.getFilteredInstrucciones()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("instructions_history_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Title block
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Bitácora de Instrucciones",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Seguimiento y control de tareas del turno",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }

            // Reset filters button
            IconButton(onClick = { viewModel.resetInstruccionFilters() }) {
                Icon(
                    imageVector = Icons.Default.FilterListOff,
                    contentDescription = "Limpiar Filtros",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Search Bar input
        OutlinedTextField(
            value = searchtext,
            onValueChange = { searchtext = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar instrucción, notas, creador...") },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            shape = RoundedCornerShape(8.dp),
            singleLine = true
        )

        // Filters horizontal row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Responsable Filter Button
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { expResp = true },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (selectedResponsable == "Todos") "Asignado" else selectedResponsable.substringBefore(" "),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(12.dp))
                }

                DropdownMenu(expanded = expResp, onDismissRequest = { expResp = false }) {
                    DropdownMenuItem(text = { Text("Todos los Responsables") }, onClick = { selectedResponsable = "Todos"; expResp = false })
                    PredefinedMockData.rolesMock.forEach { role ->
                        DropdownMenuItem(text = { Text(role) }, onClick = { selectedResponsable = role; expResp = false })
                    }
                }
            }

            // Prioridad Filter Button
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { expPrio = true },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (selectedPrioridad == "Todos") "Prioridad" else selectedPrioridad,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(12.dp))
                }

                DropdownMenu(expanded = expPrio, onDismissRequest = { expPrio = false }) {
                    DropdownMenuItem(text = { Text("Todas los niveles") }, onClick = { selectedPrioridad = "Todos"; expPrio = false })
                    Priority.values().forEach { prio ->
                        DropdownMenuItem(text = { Text(prio.label) }, onClick = { selectedPrioridad = prio.label; expPrio = false })
                    }
                }
            }

            // Estado Filter Button
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { expEst = true },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (selectedEstado == "Todos") "Estado" else selectedEstado,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(12.dp))
                }

                DropdownMenu(expanded = expEst, onDismissRequest = { expEst = false }) {
                    DropdownMenuItem(text = { Text("Todos los estados") }, onClick = { selectedEstado = "Todos"; expEst = false })
                    InstructionStatus.values().forEach { est ->
                        DropdownMenuItem(text = { Text(est.label) }, onClick = { selectedEstado = est.label; expEst = false })
                    }
                }
            }
        }

        // Active filter status count banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${filteredList.size} Instrucciones encontradas",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
            if (selectedResponsable != "Todos" || selectedPrioridad != "Todos" || selectedEstado != "Todos" || searchtext.isNotEmpty()) {
                Text(
                    text = "Filtros Activos",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // History list representation
        if (filteredList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No se encontraron instrucciones",
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                    Text(
                        text = "Intenta borrando filtros o cambiando el término",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredList) { item ->
                    InstructionItemCard(
                        instruccion = item,
                        onClick = { selectedInstructionForEdit = item },
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    // Interactive Dialog popup to adjust Instruction details
    if (selectedInstructionForEdit != null) {
        val editingItem = selectedInstructionForEdit!!
        var currentStatus by remember { mutableStateOf(editingItem.estado) }
        var updateNote by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { selectedInstructionForEdit = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Actualizar Instrucción",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "Tarea: ${editingItem.instruccion}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Divider()

                    Text(
                        text = "Cambiar Estado de Actividad:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        InstructionStatus.values().forEach { status ->
                            val activeSelection = currentStatus == status
                            val statusColor = when (status) {
                                InstructionStatus.PENDIENTE -> HighDensityAmber
                                InstructionStatus.EN_PROCESO -> HighDensityTeal
                                InstructionStatus.COMPLETADO -> HighDensityGreen
                            }
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { currentStatus = status },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (activeSelection) statusColor else statusColor.copy(alpha = 0.1f),
                                    contentColor = if (activeSelection) Color.White else statusColor
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = status.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = updateNote,
                        onValueChange = { updateNote = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Nota de avance / observación") },
                        placeholder = { Text("Ej: Terminado y verificado. Quedó listo.") }
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Asignado por: ${editingItem.creador.substringBefore(" ")}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )

                        Row {
                            TextButton(onClick = { selectedInstructionForEdit = null }) {
                                Text("Cancelar")
                            }
                            Button(
                                onClick = {
                                    viewModel.actualizarEstadoInstruccion(editingItem.id, currentStatus, updateNote)
                                    selectedInstructionForEdit = null
                                }
                            ) {
                                Text("Guardar")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InstructionItemCard(
    instruccion: Instruccion,
    onClick: () -> Unit,
    viewModel: StoreViewModel
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("instruction_history_item_${instruccion.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder(enabled = true)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Priority Badge
                val priorityColor = when (instruccion.prioridad) {
                    Priority.ALTA -> HighDensityRose
                    Priority.MEDIA -> HighDensityAmber
                    Priority.BAJA -> HighDensityGreen
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(priorityColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Prioridad ${instruccion.prioridad.label}",
                        color = priorityColor,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Time description
                Text(
                    text = instruccion.fechaHora,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = instruccion.instruccion,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Dynamic Instruction Status Badge and action indicator
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Asignado",
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Para: ${instruccion.responsable}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                val statusColor = when (instruccion.estado) {
                    InstructionStatus.PENDIENTE -> HighDensityAmber
                    InstructionStatus.EN_PROCESO -> HighDensityTeal
                    InstructionStatus.COMPLETADO -> HighDensityGreen
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(statusColor.copy(alpha = 0.1f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = instruccion.estado.label,
                        color = statusColor,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Observations text if any
            if (instruccion.observaciones.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        .padding(8.dp)
                ) {
                    Column {
                        Text(
                            text = "Bitácora / Avance:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = instruccion.observaciones,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Asignó: ${instruccion.creador}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4e-1f.coerceAtLeast(0.4f))
                )
                Text(
                    text = "Toca para actualizar ⚙️",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
