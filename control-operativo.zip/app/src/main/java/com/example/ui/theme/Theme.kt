package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = HighDensityTealDark,
  secondary = HighDensitySlateDark,
  tertiary = HighDensityAmber,
  background = HighDensityBgDark,
  surface = HighDensitySurfaceDark,
  onPrimary = HighDensitySurface,
  onSecondary = HighDensitySurface,
  onBackground = HighDensitySurface,
  onSurface = HighDensitySurface
)

private val LightColorScheme = lightColorScheme(
  primary = HighDensityTeal,
  onPrimary = HighDensitySurface,
  primaryContainer = Color(0xFFFEE2E2),      // Soft light red container
  onPrimaryContainer = Color(0xFF991B1B),    // Dark red text on primary container
  secondary = HighDensitySlate,
  onSecondary = HighDensitySurface,
  secondaryContainer = Color(0xFFEBF3FC),    // Soft D1 Blue container tint
  onSecondaryContainer = Color(0xFF1E3A8A),  // Dark blue text
  tertiary = HighDensityAmber,
  background = HighDensityBg,
  surface = HighDensitySurface,
  onTertiary = Color(0xFF1E293B),
  onBackground = Color(0xFF1E293B),          // Dark charcoal text for readability
  onSurface = Color(0xFF1E293B)             // Dark charcoal text for readability
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false,
  // Enforce D1 Colombia custom branded colors for high-fidelity operations
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
