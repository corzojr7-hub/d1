package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.PredefinedMockData
import com.example.model.Priority
import com.example.viewmodel.Screen
import com.example.viewmodel.StoreViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstruccionFormScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    var responsable by remember { mutableStateOf(PredefinedMockData.rolesMock[1]) } // default to 2nd commander
    var instruccionText by remember { mutableStateOf("") }
    var prioridad by remember { mutableStateOf(Priority.ALTA) }
    var observaciones by remember { mutableStateOf("") }

    var expandedResponsable by remember { mutableStateOf(false) }
    var showError by remember { mutableStateOf(false) }
    var showSuccessSnackbar by remember { mutableStateOf(false) }

    val preloadedTemplates = listOf(
        "Verificar fechas de vencimiento (PEPS) en el pasillo de Lácteos. Retirar averías.",
        "Tomar planilla física de temperaturas de neveras y congeladores de la tienda.",
        "Igualar frentes de aseo y licores para asegurar exhibición impecable en hora pico.",
        "Actualizar material POP / Precios D1 en las cabeceras de la entrada principal."
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("new_instruction_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Back Navigation
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = { viewModel.currentScreen.value = Screen.DASHBOARD },
                modifier = Modifier.testTag("back_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Volver al Dashboard"
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Nueva Instrucción Operativa",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Asignar deberes inmediatos al equipo de turno",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
        }

        // Info Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Instrucción Automática",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "Será registrada por ${viewModel.activeUser.value} en la fecha y hora actual simulada: ${viewModel.getCurrentFormattedTime()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
        }

        // Section: Dropdown Responsable
        Text(
            text = "1. Seleccione Responsable de la Actividad",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = responsable,
                onValueChange = {},
                readOnly = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expandedResponsable = true },
                label = { Text("Responsable Asignado") },
                trailingIcon = {
                    IconButton(onClick = { expandedResponsable = true }) {
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Expandir")
                    }
                },
                shape = RoundedCornerShape(8.dp)
            )

            DropdownMenu(
                expanded = expandedResponsable,
                onDismissRequest = { expandedResponsable = false },
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                PredefinedMockData.rolesMock.forEach { role ->
                    DropdownMenuItem(
                        text = { Text(role) },
                        onClick = {
                            responsable = role
                            expandedResponsable = false
                        }
                    )
                }
            }
        }

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        // Section: Templates shortcuts
        Text(
            text = "Shortcuts rápidos de Tienda (Sugerencias)",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary
        )

        Row(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState(), enabled = false),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            preloadedTemplates.take(2).forEach { template ->
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { instruccionText = template },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(enabled = true),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = template.substringBefore("."),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(10.dp),
                        maxLines = 2
                    )
                }
            }
        }

        // Section: Instruction input
        Text(
            text = "2. Detalle la Instrucción Operativa de Turno",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        OutlinedTextField(
            value = instruccionText,
            onValueChange = {
                instruccionText = it
                showError = false
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .testTag("instruction_text_field"),
            label = { Text("Escriba la instrucción de forma clara...") },
            placeholder = { Text("Ej: Retirar pan Horneadito vencido del mueble y reponer con lote nuevo...") },
            shape = RoundedCornerShape(8.dp),
            isError = showError && instruccionText.isBlank()
        )
        if (showError && instruccionText.isBlank()) {
            Text(
                text = "La instrucción no puede estar vacía",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.labelSmall
            )
        }

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        // Section: Priority
        Text(
            text = "3. Nivel de Prioridad de la Alerta",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Priority.values().forEach { prio ->
                val isSelected = prioridad == prio
                val baseColor = when (prio) {
                    Priority.ALTA -> HighDensityRose
                    Priority.MEDIA -> HighDensityAmber
                    Priority.BAJA -> HighDensityGreen
                }
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { prioridad = prio },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) baseColor else MaterialTheme.colorScheme.surface,
                        contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                    ),
                    shape = RoundedCornerShape(8.dp),
                    border = if (!isSelected) CardDefaults.outlinedCardBorder(enabled = true) else null
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = prio.label,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

        // Section: Observaciones
        Text(
            text = "4. Notas o Indicaciones Especiales (Opcional)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        OutlinedTextField(
            value = observaciones,
            onValueChange = { observaciones = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Observaciones / Comprobaciones requeridas") },
            placeholder = { Text("Ej: Tomar foto del reporte de temperatura una vez completado.") },
            shape = RoundedCornerShape(8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Actions Bar
        Button(
            onClick = {
                if (instruccionText.isBlank()) {
                    showError = true
                } else {
                    val success = viewModel.registrarInstruccion(
                        responsable = responsable,
                        instruccion = instruccionText,
                        prioridad = prioridad,
                        observaciones = observaciones
                    )
                    if (success) {
                        showSuccessSnackbar = true
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("submit_instruction_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Icon(
                imageVector = Icons.Default.Assignment,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Registrar y Enviar Orden de Turno",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(32.dp))
    }

    if (showSuccessSnackbar) {
        AlertDialog(
            onDismissRequest = {
                showSuccessSnackbar = false
                viewModel.currentScreen.value = Screen.DASHBOARD
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessSnackbar = false
                        viewModel.currentScreen.value = Screen.DASHBOARD
                    }
                ) {
                    Text("OK")
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = HighDensityGreen,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Instrucción Registrada")
                }
            },
            text = {
                Text("La instrucción operativa ha sido agregada con éxito para el responsable asignado.")
            }
        )
    }
}
