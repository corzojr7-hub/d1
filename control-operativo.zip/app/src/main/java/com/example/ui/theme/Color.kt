package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High Density Design Palette
val HighDensityTeal = Color(0xFFD21F26)       // Official D1 Red
val HighDensitySlate = Color(0xFF1468B3)      // Official D1 Blue
val HighDensityBg = Color(0xFFF4F5F8)         // Clean light D1 portal grey-white
val HighDensitySurface = Color(0xFFFFFFFF)    // Elegant crisp white surface
val HighDensityRose = Color(0xFFDE0613)       // Bold red for alerts/vencimiento mermas
val HighDensityRoseLight = Color(0xFFFFF1F2)  // Ultra soft rose tint
val HighDensityAmber = Color(0xFFD97706)      // Warm desaturated amber
val HighDensityAmberLight = Color(0xFFFEF3C7)  // Ultra soft amber tint
val HighDensityMuted = Color(0xFF64748B)       // Soft neutral slate desaturated
val HighDensityGreen = Color(0xFF2E7D32)       // Softened green
val HighDensityGreenLight = Color(0xFFE8F5E9)  // Ultra soft green tint

// Dark Theme Variants
val HighDensityTealDark = Color(0xFF14B8A6)    // teal-500
val HighDensitySlateDark = Color(0xFF1E293B)   // slate-800
val HighDensityBgDark = Color(0xFF020617)      // slate-950
val HighDensitySurfaceDark = Color(0xFF0F172A) // slate-900
val HighDensityMutedDark = Color(0xFF94A3B8)   // slate-400
