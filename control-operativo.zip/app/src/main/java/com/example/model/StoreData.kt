package com.example.model

import java.util.UUID

enum class Priority(val label: String) {
    ALTA("Alta"),
    MEDIA("Media"),
    BAJA("Baja")
}

enum class InstructionStatus(val label: String) {
    PENDIENTE("Pendiente"),
    EN_PROCESO("En Proceso"),
    COMPLETADO("Completado")
}

enum class MermaReason(val label: String) {
    VENCIMIENTO("Vencimiento"),
    AVARIA("Empaque Averiado"),
    ROTURA("Rotura por manipulación"),
    MAL_ESTADO("Descomposición / Organoléptico"),
    CADENA_FRIO("Pérdida Cadena de Frío")
}

enum class MermaStatus(val label: String) {
    PENDIENTE("Pendiente de Revisión"),
    REVISADO("Revisado / Ajustado"),
    RECHAZADO("Rechazado")
}

enum class UserRole(val label: String) {
    SUPERVISOR("Supervisor"),
    SEGUNDO_MANDO("Segundo al Mando"),
    TERCERO_MANDO("Tercero al Mando")
}

data class Instruccion(
    val id: String = UUID.randomUUID().toString(),
    val responsable: String, // e.g. "Liliana (2° Al Mando)"
    val instruccion: String,
    val prioridad: Priority,
    val estado: InstructionStatus,
    val observaciones: String = "",
    val fechaHora: String, // simulated e.g. "2026-06-06 08:30"
    val creador: String // "Carlos (Supervisor)"
)

data class Merma(
    val id: String = UUID.randomUUID().toString(),
    val codigoBarras: String,
    val producto: String,
    val categoria: String,
    val cantidad: Double,
    val unidad: String, // "Unidades", "Kg", "Libras", "Litros"
    val motivo: MermaReason,
    val responsableDeposito: String, // e.g. "Andrés (3° Al Mando)"
    val areaCuadrante: String, // e.g. "Pasillo 3 (Lácteos)", "Bodega Principal"
    val observaciones: String = "",
    val fotoAdjunta: String? = null, // Path description if attached
    val estadoRevision: MermaStatus = MermaStatus.PENDIENTE,
    val fechaHora: String // simulated e.g. "2026-06-06 10:15"
)

object PredefinedMockData {
    val rolesMock = listOf(
        "Carlos Gomez (Supervisor)",
        "Liliana Ortiz (Segundo al Mando)",
        "Andrés Castro (Tercero al Mando)"
    )

    val categoriasProductos = listOf(
        "Lácteos y Refrigerados",
        "Panadería y Repostería",
        "Frutas y Verduras",
        "Abarrotes y Despensa",
        "Carnes y Embutidos",
        "Aseo y Limpieza",
        "Mascotas"
    )

    val areasCuadrantes = listOf(
        "Neveras / Temperatura Controlada",
        "Pasillo 1 (Abarrotes)",
        "Pasillo 2 (Aseo y Hogar)",
        "Isla de Frutas y Verduras",
        "Góndola de Panadería",
        "Bodega Seca Principal",
        "Línea de Cajas / Surtido Impulso"
    )

    val unidadesMedida = listOf(
        "Unidades",
        "Kilogramos (Kg)",
        "Litros (L)",
        "Paquetes / Bolsas"
    )

    val productosPredeterminados = listOf(
        Triple("7702004012345", "Leche Entera Latti 1L", "Lácteos y Refrigerados"),
        Triple("7702008719283", "Pan Tajado Molde Horneadito 450g", "Panadería y Repostería"),
        Triple("7705001122334", "Papas Fritas Lisas Crocantes D1 150g", "Abarrotes y Despensa"),
        Triple("7707328402911", "Detergente Líquido Rendidor Rendy 3L", "Aseo y Limpieza"),
        Triple("7703002938127", "Jamón de Cerdo Premium d'Sabor 250g", "Carnes y Embutidos"),
        Triple("7704001928374", "Café Molido Don Café Premium 500g", "Abarrotes y Despensa"),
        Triple("7706002819203", "Bolsa de Manzanas Rojas Importadas x 1Kg", "Frutas y Verduras"),
        Triple("7708003920193", "Comida para Perros Can-Hijo 2Kg", "Mascotas")
    )

    val instruccionesIniciales = listOf(
        Instruccion(
            responsable = "Liliana Ortiz (Segundo al Mando)",
            instruccion = "Verificar temperaturas de neveras del pasillo lácteos (deben registrarse entre 2°C y 4°C en la bitácora física).",
            prioridad = Priority.ALTA,
            estado = InstructionStatus.PENDIENTE,
            fechaHora = "2026-06-06 06:15",
            creador = "Carlos Gomez (Supervisor)",
            observaciones = "Inspección urgente para evitar pérdidas por cadena de frío rota."
        ),
        Instruccion(
            responsable = "Andrés Castro (Tercero al Mando)",
            instruccion = "Rotar panadería Horneadito de góndola delantera. Ubicar fechas más cercanas adelante (PEPS) y retirar vencidos.",
            prioridad = Priority.ALTA,
            estado = InstructionStatus.EN_PROCESO,
            fechaHora = "2026-06-06 07:45",
            creador = "Carlos Gomez (Supervisor)",
            observaciones = "Se reportó acumulación de pan de ayer."
        ),
        Instruccion(
            responsable = "Liliana Ortiz (Segundo al Mando)",
            instruccion = "Ajustar cartelera de ofertas de temporada D1 en puerta principal. Retirar promociones de fin de mes.",
            prioridad = Priority.MEDIA,
            estado = InstructionStatus.COMPLETADO,
            fechaHora = "2026-06-05 15:30",
            creador = "Carlos Gomez (Supervisor)",
            observaciones = "Fotos enviadas por chat interno. Quedó organizado."
        ),
        Instruccion(
            responsable = "Andrés Castro (Tercero al Mando)",
            instruccion = "Surtir e igualar pasillo de aseo y licores. Cuadrar frentes en cajas para hora pico de la tarde.",
            prioridad = Priority.BAJA,
            estado = InstructionStatus.PENDIENTE,
            fechaHora = "2026-06-06 09:10",
            creador = "Liliana Ortiz (Segundo al Mando)"
        )
    )

    val mermasIniciales = listOf(
        Merma(
            codigoBarras = "7702008719283",
            producto = "Pan Tajado Molde Horneadito 450g",
            categoria = "Panadería y Repostería",
            cantidad = 4.0,
            unidad = "Unidades",
            motivo = MermaReason.VENCIMIENTO,
            responsableDeposito = "Andrés Castro (Tercero al Mando)",
            areaCuadrante = "Góndola de Panadería",
            observaciones = "Vote vencido lote 06-A6. Retirado de exhibición en el recorrido matutino.",
            fotoAdjunta = "vencimiento_pan.png",
            estadoRevision = MermaStatus.PENDIENTE,
            fechaHora = "2026-06-06 08:15"
        ),
        Merma(
            codigoBarras = "7702004012345",
            producto = "Leche Entera Latti 1L",
            categoria = "Lácteos y Refrigerados",
            cantidad = 2.0,
            unidad = "Unidades",
            motivo = MermaReason.AVARIA,
            responsableDeposito = "Liliana Ortiz (Segundo al Mando)",
            areaCuadrante = "Neveras / Temperatura Controlada",
            observaciones = "Bolsas perforadas durante caja de transporte rota de la distribuidora.",
            fotoAdjunta = "leche_averia.png",
            estadoRevision = MermaStatus.REVISADO,
            fechaHora = "2026-06-05 11:20"
        ),
        Merma(
            codigoBarras = "7706002819203",
            producto = "Bolsa de Manzanas Rojas Importadas x 1Kg",
            categoria = "Frutas y Verduras",
            cantidad = 1.5,
            unidad = "Kilogramos (Kg)",
            motivo = MermaReason.MAL_ESTADO,
            responsableDeposito = "Andrés Castro (Tercero al Mando)",
            areaCuadrante = "Isla de Frutas y Verduras",
            observaciones = "Manzanas con magulladuras severas y hongos de humedad en empaque plástico cerrado.",
            fotoAdjunta = null,
            estadoRevision = MermaStatus.PENDIENTE,
            fechaHora = "2026-06-06 10:45"
        ),
        Merma(
            codigoBarras = "7705001122334",
            producto = "Papas Fritas Lisas Crocantes D1 150g",
            categoria = "Abarrotes y Despensa",
            cantidad = 1.0,
            unidad = "Unidades",
            motivo = MermaReason.ROTURA,
            responsableDeposito = "Liliana Ortiz (Segundo al Mando)",
            areaCuadrante = "Pasillo 1 (Abarrotes)",
            observaciones = "Cliente tropezó caja de exhibición aplastando un empaque.",
            fotoAdjunta = "papas_rotas.png",
            estadoRevision = MermaStatus.REVISADO,
            fechaHora = "2026-06-04 16:30"
        )
    )
}
